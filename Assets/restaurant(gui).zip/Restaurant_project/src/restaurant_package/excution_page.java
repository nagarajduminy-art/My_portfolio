package restaurant_package;

public class excution_page {

	public static void main(String[] args) {
		Home_page hp=new Home_page();
		hp.setTitle("Restaurant home page");
		hp.setSize(1700,900);
		hp.setVisible(true);
//		admin_page ap=new admin_page();
//		ap.setTitle("Admin page");
//		ap.setSize(1700,900);
//		ap.setVisible(true);
//		Waiter_page wp=new Waiter_page();
//		wp.setTitle("Admin page");
//		wp.setSize(1700,900);
//		wp.setVisible(true);
	}

}
