package demo;

public class CashierDashboard {

	public CashierDashboard() {
		// TODO Auto-generated constructor stub
	}

}
